cd 00.program

## get the start time
START=$(date +%s)
StartTime=$(date)

./27_ave_etn8 < ../0_input

## get the end time
END=$(date +%s)
EndTime=$(date)
## calculate the time cost
DIFF=$(($END - $START))

echo "
Start time: $StartTime
End time: $EndTime
Time cost (second): $DIFF
"
