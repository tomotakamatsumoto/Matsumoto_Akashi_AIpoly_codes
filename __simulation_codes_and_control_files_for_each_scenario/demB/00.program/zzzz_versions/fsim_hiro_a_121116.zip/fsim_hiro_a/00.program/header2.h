/*macros*/
/*options*/
#define DO_WRITE		1				
#define DONT_WRITE		0
#define DO_RESET		1	/* init data after prerun - 0 used for some pop fluct models */
#define DONT_RESET		0
#define INIT_RUN		0
#define PRE_RUN			1
#define REP_RUN			2
/*parameters*/
#define POP_MODEL		"constPopSize"		/*population fluctuation model */
#define MULTIHITFACTOR	10					/*every MULTIHITFACTOR*hitnum iterations check to see if there are free sites*/
#define INITMCU			0.6					/*Initial MCU value used to initialize the sequences                                  CHANGE THIS TO EQUILIBRIUM VALUE FOR MCU MODEL */
#define S_MODEL			"sampleAtEveryMutation"	/*sampling model for s values*/

/*constants*/
#define MAXSEQLEN		1500				/*maximum length of sequence has to be multiple of 3*/
#define MAXSAMPLENUM	25					/*maximum samplesize*/	
#define MAXSEQNUM		5000				/*maximum number of sequences even when fluctuating*/
#define MINSEQNUM		500					/*minimum number of sequences even under population fluctuation*/
#define MAXGEN			500000				/*maximum of inirungen, prerungen and reprungen*/
#define MAXFIXATIONS	200000				/*maximum number of fixations permitted in a single initrun or prerun or reprun*/

/*---------------------------------------------------------------------------------------*/
/*structure definitions*/
struct seq_str
{
	char *site;					/*string of bases for each sequence*/
	long baseCount0[3+1];			/*baseCount0[j] is the number of 0s at sitePos where (sitePos+2)%3+1=j*/
	long baseCount1[3+1];			/*baseCount1[j] is the number of 1s at sitePos where (sitePos+2)%3+1=j*/
	long tot_1_ct;
};

struct siteData_str
{	
	char ancSite;							/*ancestral base at current site*/
	long freqs0;					/*frequency of 0s in the population at current site*/
	long freqs1;					/*frequency of 1s in the population at current site*/
	long fixNum01;					/*number of fixations from 0 to 1 at current site in the population during current replicate */
	long fixNum10;					/*number of fixations from 1 to 0 at current site in the population during current replicate */
	long mutNum01;					/*number of mutations from 0 to 1 at current site in the population during current replicate */
	long mutNum10;					/*number of mutations from 1 to 0 at current site in the population during current replicate */
	long recNum;					/*number of crossovers at current site during current replicate */
};

double *w_dat_static;

/*flags read from the control file*/
//long noMultiHit;								/*1=no multiple hits 0=permit multiple hits*/

/*parameters read from the control file*/
//long repNum;						/*Total number of replicates for the simulation*/

//long initRunGen;					/*number of repRunGen for the initial run */
//long preRunGen;					/*number of repRunGen for the prerun before each reprun*/
//long repRunGen;					/*number of generations for the replicate run*/	

//long initSeqNum;					/*Initial number of sequences*/
//long seqLen;						/*Length of sequences as number of bases*/
//long sampleNum;					/*Number of sequences to be sampled to collect data*/

//double c;									/*per site per generation recombination rate*/
//double u10;									/*the 1->0 mutation rate common for all positions*/
//double u01;									/*the 0->1 mutation rate common for all positions*/
//double Nes2;								/* 2Nes for MCU model */

char *outFileName, *outFileName2, *outFile_segsites, *outFile_MCU;			/*name of output file*/
char *outFileExtn;			/*outputfilename extension*/
//char *ctlFileName;			/*name of control file*/
//char version[11];							/*version string will be appended to filename before extension*/
//char fsimVersion[11];						/*version of fsim. the above is the version of the simulation*/
//char *comments;				/*comments - will be output into the outputfile*/
//char *machineName;			/*machine on which the program is running*/
FILE *fpOut, *fpOut2, *fpOut_segsites, *fpOut_MCU;								/*output file pointer*/

/*variables used for the simulation - data being processed*/
struct seq_str *seq, *newSeq;
struct siteData_str	*siteData;	/*array of sitedata structures */
double *sArray;					/*array of s values for the sequence*/

long *preRunPopFluct;		/*array to store the population sizes during each generation in the prerun*/
long *popSizeArray;		/*array used to store the population sizes for each gen for a given cycle*/
long curPopSize;					/*The current population size at any time*/
long curGenNum;					/*the current generation number*/
long curRepNum;					/*the current replicate*/
long *sampleSeqs;	/*indices of sequences that are to be sampled for the current replicate*/		

/* data for doMutations() */
long *hitSites10;	/*indices of 1 sites to be mutated*/
long *hitSites01;	/*indices of 0 sites to be mutated*/

/* data for doRecombination() */
long *seqIndex;			/*Array to store the indices to pair sequences randomly*/
long *crossOverSite;	/*array to store the positions of crossovers*/

/* data for getNextGenSeqs() and getNextGenSeqs_MCU() */
double *wData;				/*array that stores the weight for each sequence*/
double *freqs;				/*expected frequencies of current individuals*/
long *newFreqs;			/*obtained frequencies of offsprings for current generation*/

/*arrays of flags for processing data*/
long *curSeqHitSite; 			/*1=site already hit in current mutagenesis of a gene, 0=not*/
long *curGenHitSite;			/*1=site already hit in current generation (across genes) 0=not*/
long *polySite;					/*1=site is segregating in population, 0=not*/		
long *crossHitSite;				/*1=site already selected as crossover site in a given generation, 0=not*/

/*variables for data collection from each replicate. */
long sampleFix01[3+1];				/*Fixations of 0->1 due to sampling (fixed in sample, but not in pop) */
long sampleFix10[3+1];				/*Fixations of 1->0 due to sampling*/
long sampleFixNum;					/*Total number of fixations due to sampling */
long *sampleFixPos;					/*Position of fixed (due to sampling) sites in the sample*/
long sampleSeg01[3+1];				/*segregating sites in the sample with ancSite 0*/
long sampleSeg10[3+1];				/*segregating sites in the sample with ancSite 1*/
long sampleSegNum;					/*Total number of segregating sites in the sample*/
long *sampleSegPos;					/*Position of segregating sites in the sample*/

long popRecNum;					/*Total number of crossovers in the population across all sites */

/*for every fixation in the population, store the derived state, the position in the sequence, and the fitness effect */
long popFixNum;					/*number of mutations fixed in the replicate - used to access the following arrays*/
char *fixSite;				/*the site that got fixed ie. if 0 was fixed then 0 else 1*/
long *fixSitePos;	/*Positions of fixed sites in current replicate*/
double *fixSiteSval;				/*S values of sites fixed in current replicate*/

long repTime;						/*time in seconds for the current replicate*/

long genMultiHitCount;				/*Total of multiple hits in a generation across all generations for current rep*/
long segMultiHitCount;				/*Total of multiple hits at segregating sites across all generations*/

/*function declarations*/
long checkParameters(struct userPref_str *userPrefp);
long writeFsimInfo(struct userPref_str *userPrefp);
long initData(struct userPref_str *userPrefp);
long doFsim(struct userPref_str *userPrefp, long genNum, long flagReset, long repType);
long getPopScenario(struct userPref_str *userPrefp, long repType, long genNum);
long resetData(struct userPref_str *userPrefp);
long doMutations(struct userPref_str *userPrefp);
long getHitSites(struct userPref_str *userPrefp, char origSite, long baseCount, long curSeq, long codPos, long* hitSites, long numHits);
long getPosNthChar(struct userPref_str *userPrefp, char *site, long codPos, long hitCod, char origSite);
long doRecombination(struct userPref_str *userPrefp);
long getNextGenSeqs(struct userPref_str *userPrefp);

long updateCounts(struct userPref_str *userPrefp);
double sampleSval(struct userPref_str *userPrefp, long sitePos, char ancSite);
long writeRepData(struct userPref_str *userPrefp);
long getRepData(struct userPref_str *userPrefp);
long getSample(struct userPref_str *userPrefp);
long endSim(struct userPref_str *userPrefp);
long checkBaseCounts(struct userPref_str *userPrefp, long pos);

void get_static_w_dat(struct userPref_str *userPrefp);
long getNextGenSeqs_MCU(struct userPref_str *userPrefp);

/*--------------------------------------------------------------------------------*/
/*function that initializes all the variables. whenever this function is called
the whole data will be reset. used only at the begining of the whole simulation (not for each replicate) 
some of the variables are reset between prerun and replicate */
long initData(struct userPref_str *userPrefp)
{
	long debug = 1, ct;
	long numOnes;					/*the number of ones in a sequence*/
	long numZeros;					/*the number of zeros in a sequence*/
	long curSite;					/*refers to the current site*/
	long curSeq;					/*refers to the current sequence*/
	long randSite;					/*site that is randomly picked to be filled with a 1*/
	double mcu;						/*mcu for the sequence*/
//	long *site;						/*temporary array to initialize the sequence*/
	
	printf("Initializing Data\n");
//	site = (long *) memAlloc(MAXSEQLEN + 1, sizeof(long), "");
	
	/* memory allocations for global variables */
	outFileName			= (char *) memAlloc (MAXLINECHAR + 1, sizeof(char), "outFileName");
	outFileName2		= (char *) memAlloc (MAXLINECHAR + 1, sizeof(char), "outFileName2");
	outFile_segsites	= (char *) memAlloc (MAXLINECHAR + 1, sizeof(char), "outFile_segsites");
	outFile_MCU			= (char *) memAlloc (MAXLINECHAR + 1, sizeof(char), "outFile_MCU");
	
	seq		= (struct seq_str *) memAlloc (userPrefp->initSeqNum + 1, sizeof(struct seq_str), "seq array");
	newSeq	= (struct seq_str *) memAlloc (userPrefp->initSeqNum + 1, sizeof(struct seq_str), "new seq array");
	for (curSeq = 0; curSeq <= userPrefp->initSeqNum; curSeq++)
	{
		seq[curSeq].site	= (char *) memAlloc (userPrefp->seqLen + 1, sizeof(char), "");
		newSeq[curSeq].site	= (char *) memAlloc (userPrefp->seqLen + 1, sizeof(char), "");
	}
	siteData = (struct siteData_str *) memAlloc (userPrefp->seqLen + 1, sizeof(struct siteData_str), "siteData"); 

	sArray = (double *) memAlloc (userPrefp->seqLen + 1, sizeof(double), "sArray");

	preRunPopFluct 		= (long *) memAlloc (MAXGEN + 1, sizeof(long), "preRunPopFluct");
	popSizeArray 		= (long *) memAlloc (MAXGEN + 1, sizeof(long), "popSizeArray");
	sampleSeqs 			= (long *) memAlloc (MAXSAMPLENUM + 1, sizeof(long), "popSizeArray");
	
	curSeqHitSite 		= (long *) memAlloc (userPrefp->seqLen + 1, sizeof(long), ""); 
	curGenHitSite 		= (long *) memAlloc (userPrefp->seqLen + 1, sizeof(long), "");
	polySite 			= (long *) memAlloc (userPrefp->seqLen + 1, sizeof(long), "");
	crossHitSite 		= (long *) memAlloc (userPrefp->seqLen + 1, sizeof(long), "");
	
	sampleFixPos		= (long *) memAlloc (userPrefp->seqLen + 1, sizeof(long), ""); 
	sampleSegPos		= (long *) memAlloc (userPrefp->seqLen + 1, sizeof(long), ""); 

	fixSite				= (char *) memAlloc (MAXFIXATIONS + 1, sizeof(char), "fixSite");
	fixSitePos			= (long *) memAlloc (MAXFIXATIONS + 1, sizeof(long), "fixSitePos");
	fixSiteSval  		= (double *) memAlloc (MAXFIXATIONS + 1, sizeof(double), "fixSiteSval");

	/* memory allocations for doMutations() */
	hitSites10 			= (long *) memAlloc (userPrefp->seqLen + 1, sizeof(long), "hitSites10");
	hitSites01 			= (long *) memAlloc (userPrefp->seqLen + 1, sizeof(long), "hitSites01");

	/* memory allocations for doRecombination() */
	seqIndex 			= (long *) memAlloc (userPrefp->initSeqNum + 1, sizeof(long), "seqIndex");
	crossOverSite 		= (long *) memAlloc (userPrefp->seqLen + 1, sizeof(long), "crossOverSite");
	
	/* memory allocations for getNextGenSeqs() */
	wData 				= (double *) memAlloc (userPrefp->initSeqNum + 1, sizeof(double), "wData");
	freqs 				= (double *) memAlloc (userPrefp->initSeqNum + 1, sizeof(double), "freqs");
	newFreqs 			= (long *) memAlloc (userPrefp->initSeqNum + 1, sizeof(long), "newFreqs");


	

	/* initialize output files */
	sprintf(outFileName,  "%s%s%s_1_%s.%s", userPrefp->rootOutputFolder, userPrefp->dirSep, userPrefp->outFileName, userPrefp->version, userPrefp->outFileExtn);
	sprintf(outFileName2, "%s%s%s_2_%s.%s", userPrefp->rootOutputFolder, userPrefp->dirSep, userPrefp->outFileName, userPrefp->version, userPrefp->outFileExtn);
	sprintf(outFile_segsites, "%s%s%s_segsites_%s.%s", userPrefp->rootOutputFolder, userPrefp->dirSep, userPrefp->outFileName, userPrefp->version, userPrefp->outFileExtn);
	sprintf(outFile_MCU, "%s%s%s_MCU_%s.%s", userPrefp->rootOutputFolder, userPrefp->dirSep, userPrefp->outFileName, userPrefp->version, userPrefp->outFileExtn);
	
	fpOut			= fileOpen(outFileName, "wb");
	fpOut2			= fileOpen(outFileName2, "wb");
	fpOut_segsites	= fileOpen(outFile_segsites, "wb");
	fpOut_MCU		= fileOpen(outFile_MCU, "wb");
	
	idumVal = userPrefp->idum_init;
	checkParameters(userPrefp);
	
	if (debug == 1)	printf("\tpos 1\n");
	if (debug == 1)	printf("\tpos 2\n");
	
	/*finds the initial number of 1s and 0s*/
	mcu = INITMCU;								/* this should not be initialized to 0.50 for MCU model !!!!!!!!!!!!!!!!!!!!!! */
	numOnes = mcu * userPrefp->seqLen;
	numZeros = userPrefp->seqLen - numOnes;
	
	/*iniitializes the temporary array and fills the first sequence with all zeros
	also initializes the siteData structure*/
	for(curSite=1; curSite <= userPrefp->seqLen; curSite++)
	{
//		site[curSite] = curSite;
		seq[1].site[curSite] = '1';		/* set to all 1's */
	}
	
	if (debug == 1)	printf("\tpos 3\n");
	/*  */
	ct = 0;
	while (ct < numZeros)
	{
		randSite = getRandLong_(1, userPrefp->seqLen);
		if (seq[1].site[randSite] == '1')
		{
			ct++;
			seq[1].site[randSite] = '0';
		}
	}
	if (debug == 1)
	{
		for (curSeq=1; curSeq<=1; curSeq++)
		{
			printf("seq test: %5ld\n", curSeq);
			for(curSite = 1; curSite <= userPrefp->seqLen; curSite++)
				printf("%c", seq[curSeq].site[curSite]);
			printf("\n");
		}
		printf("\n");
		printf("\n");
	}
	
	/*find sites with ones*/
//	for(curSite=1; curSite<=numOnes; curSite++)
//	{
		/* randomly picks a number from those that are not already picked and then write a 1 in the seq data structure at the corresponding position */
//		randSite = getRandLong_(curSite, userPrefp->seqLen);
//		seq[1].site[site[randSite]] = 1;
//		site[randSite] = site[curSite];
//	}
	
//	printf("preRunGen 11: %0ld\n", preRunGen);
	/* Initializes the basecounts in the sequence structure and also the sitedata structure */
	seq[1].baseCount0[1] = seq[1].baseCount0[2] = seq[1].baseCount0[3] = 0;
	seq[1].baseCount1[1] = seq[1].baseCount1[2] = seq[1].baseCount1[3] = 0;
	for(curSite = 1; curSite <= userPrefp->seqLen; curSite++)
	{
		/* For each site increment baseCounts, fix siteData elements */
		if(seq[1].site[curSite] == '1')
		{
			seq[1].baseCount1[sitePosToCodPos(curSite)]++;
			siteData[curSite].ancSite = '1';
			siteData[curSite].freqs1 = userPrefp->initSeqNum;
			siteData[curSite].freqs0 = 0;
		}
		else
		{
			seq[1].baseCount0[sitePosToCodPos(curSite)]++;
			siteData[curSite].ancSite = '0';
			siteData[curSite].freqs0 = userPrefp->initSeqNum;
			siteData[curSite].freqs1=0;
		}
		/*Reset Counts in siteData structure*/
		siteData[curSite].fixNum01 = 0;
		siteData[curSite].fixNum10 = 0;
		siteData[curSite].mutNum01 = 0;
		siteData[curSite].mutNum10 = 0;
		siteData[curSite].recNum = 0;
	}
	if (debug == 1)	printf("\tpos 4\n");
	
//	printf("preRunGen 12: %0ld\n", preRunGen);
	/*check if everything was ok*/
	if (seq[1].baseCount0[1] + seq[1].baseCount0[2] + seq[1].baseCount0[3] != numZeros)
		errorOut(("Invalid 0 counts(!=%lu) while initializing sequence", numZeros));
	if (seq[1].baseCount1[1] + seq[1].baseCount1[2] + seq[1].baseCount1[3] != numOnes)
		errorOut(("Invalid 1 counts(!=%lu) while initializing sequence", numOnes));
	
//	printf("preRunGen 12a: %0ld\n", preRunGen);
	/*copy seq[1] to all sequences*/
	for(curSeq=2; curSeq<= userPrefp->initSeqNum; curSeq++)
	{
		seq[curSeq] = seq[1];
		/* not sure if the values are set equal for the seqs or the array points to the same location */
// 		for (curSite = 1; curSite <= userPrefp->seqLen; curSite++)
// 			seq[curSeq].site[curSite] = seq[1].site[curSite];
	}
	if (debug == 1)
	{
		for (curSeq=1; curSeq<=userPrefp->initSeqNum; curSeq++)
		{
			printf("seq: %5ld\n", curSeq);
			for (curSite = 1; curSite <= userPrefp->seqLen; curSite++)
				printf("%c", seq[curSeq].site[curSite]);
			printf("\n");
		}
		printf("\n");
	}
	
	
	
//	printf("preRunGen 12b: %0ld\n", preRunGen);
	/* Initializes the sArray */
	for (curSite=1; curSite<=userPrefp->seqLen; curSite++)
	{
		/* sArray[curSite]=sampleSval(curSite, seq[1].site[curSite]); */
		sArray[curSite]=0.0;
	}
//	printf("preRunGen 12c: %0ld\n", preRunGen);
	for (curSite=1; curSite<=MAXGEN; curSite++)
	{
		popSizeArray[curSite] = userPrefp->initSeqNum;
	}
	curPopSize = userPrefp->initSeqNum;

//	printf("preRunGen 12d: %0ld\n", preRunGen);
	for(curSeq=1; curSeq <= MAXSAMPLENUM; curSeq++)
		sampleSeqs[curSeq]=0;
	
	if (debug == 1)	printf("\tpos 5\n");
//	printf("preRunGen 13: %0ld\n", preRunGen);
	/*Initializes the flags*/
	for (curSite=1; curSite<=userPrefp->seqLen; curSite++)
	{
		curSeqHitSite[curSite] = 0;
		curGenHitSite[curSite] = 0;
		polySite[curSite] = 0;
		crossHitSite[curSite] = 0;
	}
	/*Initializes the counts*/
	sampleFix01[1]=sampleFix01[2]=sampleFix01[3]=0;
	sampleFix10[1]=sampleFix10[2]=sampleFix10[3]=0;
	sampleFixNum=0;
	sampleSeg01[1]=sampleSeg01[2]=sampleSeg01[3]=0;
	sampleSeg10[1]=sampleSeg10[2]=sampleSeg10[3]=0;
	sampleSegNum=0;
	for (curSite=1;curSite<=userPrefp->seqLen;curSite++)
	{
		sampleFixPos[curSite]=0;
		sampleSegPos[curSite]=0;
	}
	popRecNum=0;
	popFixNum=0;
	for(curSite=1; curSite<=MAXFIXATIONS; curSite++)
	{
		fixSite[curSite]     = '-';
		fixSitePos[curSite]  = 0;
		fixSiteSval[curSite] = 0;
	}
	repTime=0;
	genMultiHitCount=0;
	segMultiHitCount=0;
	if (debug == 1)	printf("\tpos 9\n");
	
//	printf("preRunGen 7: %0ld\n", preRunGen);
//	free(site);
	return 0;
}
/*--------------------------------------------------------------------------------*/
